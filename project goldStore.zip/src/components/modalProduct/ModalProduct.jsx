import "./modalProduct.css"
import React, { useEffect, useState } from 'react'
import CloseIcon from '@mui/icons-material/Close';
import { useDispatch, useSelector } from "react-redux";
import { GetProducts, PostProducts } from "../slices/ProductsSlice";
import DeleteForeverIcon from '@mui/icons-material/DeleteForever';
import Rotate90DegreesCcwIcon from '@mui/icons-material/Rotate90DegreesCcw';
import imageUploaderPng from "../modalProduct/productImage/imageUpload.png"
import ReactImageUploading from "react-images-uploading";
import { useSearchParams } from "react-router-dom";

export default function ModalProduct() {
  const onChange = (imageList, addUpdateIndex) => {
    setImagess(imageList);
  };
  const [searchParams, setSearchParams] = useSearchParams()
  const maleFemaleQuery = +searchParams.get("gender") || "";
  const category = useSelector(state => state.category.category)
  const products = useSelector(state => state.products.products)
  const subCategory = useSelector(state => state.subcategory.subcategory)
  const [imagess, setImagess] = useState([]);
  const [img, setImg] = useState({});
  const dispatch = useDispatch()
  const [prodModal, setProdModal] = useState(false)
  const [prod, setProd] = useState("")
  const [prodCost, setProdCost] = useState("")
  const gender = useSelector(state => state.gender.gender)
  const subcategoryQuery = +searchParams.get("subcategory");
  const categoryQuery = +searchParams.get("category");
  useEffect(() => {
    dispatch(GetProducts())
  }, [dispatch])
  return (
    <>
      <div
        onClick={() => {
          setProdModal(!prodModal)
        }}
        className='modal-product-box'>
        +
      </div>
      {prodModal ? (
        <div
          className='transparent-box'
          onClick={() => {
            setProdModal(!prodModal)
          }}>
          <div
            className='prod-add-box'
            onClick={(e) => {
              e.stopPropagation()
            }}
          >
            <div className="prod-add-box2">
              <div className='prod-add-top'>
                <div className="prod-add-top-left">
                  <h1 className="prod-add-title">Добавить Изделия</h1>
                </div>
                <div className="prod-add-top-right">
                  <div
                    onClick={() => {
                      setProdModal(!prodModal)
                    }}
                    className='close-prod-add'>
                    <CloseIcon></CloseIcon>
                  </div>
                </div>
              </div>
              <div className="prod-add-category-box">
                <div className="prod-add-malefemale-category-box">
                  <div className="prod-add-malefemale-box">
                    {gender.map(({ id, logo }) => {
                      const isSelected = (id === maleFemaleQuery);
                      return (
                        <div
                          onClick={() => {
                            setSearchParams({ gender: id })
                          }}
                          className={`maleFemaleIcons ${isSelected ? 'selectedBorder' : ''}`}
                          key={id}
                        >
                          <img
                            className='icon'
                            src={logo} />
                        </div>
                      )
                    })}
                  </div>
                  <div className="prod-add-category">
                    {category.map((category) => {
                      const isSelected = (category.id === subcategoryQuery);
                      return category.parentId === maleFemaleQuery && (
                        <div
                          key={category.id}
                          onClick={(() => {
                            setSearchParams({ gender: maleFemaleQuery, category: category.id })
                          })

                          }
                          style={{ border: category.id === categoryQuery && "2px solid #939393" }}
                          className={`gender-category-item2 ${isSelected ? 'genderSelectedBorder2' : ''}`}>
                          <div className='CategoryImg'>
                            <img
                              className='item-category-img'
                              src={category.categoryImg}
                              alt={`${category.name}.png`}
                            />
                          </div>
                          <div className='category-img-name'>
                            {category.name}
                          </div>
                        </div>
                      )

                    })}
                  </div>
                </div>
                <nav className="prod-add-subCategory">
                  <ul className="prod-add-ul">
                    {subCategory.map(({ subname, id, parentId }) => {
                      return parentId === categoryQuery && (
                        <li
                          key={id}
                          className='prod-add-li2'
                          onClick={(() => {
                            setSearchParams({ gender: maleFemaleQuery, category: categoryQuery, subcategory: id })
                          })}
                          style={{ borderBottom: id === subcategoryQuery && "4px solid #0008C1" }}
                        >
                          {subname}
                        </li>
                      )
                    })}
                  </ul>
                </nav>
              </div>
              <div className="image-add-and-inps-box">
                <div className="img-parent-box">
                  {/* image-uploader */}
                  <div className="img-box">
                    <div className="img-uploader-box">
                      <ReactImageUploading
                        value={imagess}
                        onChange={onChange}
                        maxNumber={1}
                        dataURLKey="data_url">
                        {({
                          imageList,
                          onImageUpload,
                          onImageUpdate,
                          onImageRemove,
                          dragProps,
                        }) => (
                          <div className="upload-image2">
                            {imageList &&
                              <button
                                className='imgae-uploader2'
                                onClick={onImageUpload}
                                {...dragProps}
                              >
                                <img src={imageUploaderPng} alt="" />
                                <p className='Img-upload-text-load2'>Загрузить Фото</p>
                              </button>}
                            &nbsp;
                            {imageList.map((image, index) => {
                              image && setImg(image["data_url"]);
                              console.log(imageList);
                              return <div key={index} className="image-item2">
                                <img src={image["data_url"]} width="100" />
                                <div className="image-item-btn-wrapper2">
                                  <div className='modal-img-remove-update2'>
                                    <span className='update-button2' onClick={() => onImageUpdate(index)}>
                                      <Rotate90DegreesCcwIcon fontSize="small" />
                                    </span>
                                    <span className='remove-button2' onClick={() => onImageRemove(index)}>
                                      <DeleteForeverIcon fontSize="small" />
                                    </span>
                                  </div>
                                </div>
                              </div>
                            })}
                          </div>
                        )}
                      </ReactImageUploading>
                    </div>
                    <div className="mini-imgs-box">
                      <div className="mini-img">
                        <div className="ring-box-close">X</div>
                      </div>
                      <div className="mini-img">
                        <div className="ring-box-close">X</div>
                      </div>
                      <div className="mini-img">
                        <div className="ring-box-close">X</div>
                      </div>
                      <div className="mini-img">
                        <div className="ring-box-close">X</div>
                      </div>
                    </div>
                  </div>
                </div>
                {/* add-articul */}
                <div className="articul-parent-box">
                  <div className="prod-add-img-title">Артикул</div>
                  <div className="prod-add-img-cost">
                    <input
                      className="prod-add-inp"
                      value={prod}
                      type="text"
                      onChange={(e) => {
                        setProd(e.target.value)
                      }}
                    />
                  </div>
                </div>
                {/* add-cost */}
                <div className="articul-parent-box">
                  <div className="prod-add-img-title2">Цена </div>
                  <div className="prod-add-img-cost">
                    <input
                      className="prod-add-inp"
                      value={prodCost}
                      type="number"
                      onChange={((e) => {
                        setProdCost(e.target.value)
                      })}
                    />
                  </div>
                </div>
              </div>
              <div className="button-box">
                <button
                  onClick={() => {
                    
                    if (prod.trim() !== "" && prodCost !== "" && imagess.length == 1, maleFemaleQuery !== "", subcategoryQuery !== "") {
                      dispatch(PostProducts({ prodImg: img, prodName: prod, price: prodCost, parentId: subcategoryQuery })).then(() => {
                        dispatch(GetProducts())
                        setProdModal(false)
                        setProd("")
                        setProdCost(null)
                        setImagess([])
                      })
                    } else {
                      alert("chose")
                    }
                  }
                  }
                  className="prod-add-product">Добавить
                </button>
              </div>
            </div>
          </div>
        </div>) : null}
    </>
  )
}
