import "./header.css"
import React, { useState } from 'react'
import { useDispatch } from "react-redux";
import { useSelector } from "react-redux";
import SearchIcon from '@mui/icons-material/Search';
import { ProducHandleValue } from "../slices/ProductsSlice"
export default function SectionOne() {
   const [filterVal, setFilterVal] = useState("")
   const dispatch = useDispatch()
   return (
      <>
         <div className="sectionOne">
            <div className="inp-box">
               <input
                  onChange={(e) => {
                     setFilterVal(e.target.value)
                  }}
                  value={filterVal}
                  type="text"
                  className="global-search"
                  placeholder="Поиск"
               />
               <div
                  onClick={() => {
                     if (filterVal.trim() !== "") {
                        dispatch(ProducHandleValue(filterVal))
                     }
                  }}
                  className="icon-global-search-box">
                  <SearchIcon
                     className="icon-global-search"
                     fontSize="medium">
                  </SearchIcon>
               </div>
            </div>
         </div>
      </>
   )
}
