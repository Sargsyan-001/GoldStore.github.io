import "./filter.css";
import "./products.css"
import "./category.css"
import "./maleFemale.css"
import "./subCategory.css"
import { GetSubCategory } from '../slices/NavSlice';
import { GetMaleFemale } from '../slices/MaleFemaleSlice';
import { GetGenderCategory } from '../slices/GenderCategorySlice';
import { GetProducts } from "../slices/ProductsSlice"
import { useDispatch, useSelector } from 'react-redux';
import { useSearchParams } from 'react-router-dom';
import { useEffect, useState } from 'react'
import ModalCategory from '../modalCategory/ModalCategory';
import NavModalAdd from '../navModalAdd/NavModalAdd'
import ModalProduct from "../modalProduct/ModalProduct"
import FilterAltOutlinedIcon from '@mui/icons-material/FilterAltOutlined';
import ArrowBackIosIcon from '@mui/icons-material/ArrowBackIos';
import ArrowForwardIosIcon from '@mui/icons-material/ArrowForwardIos';
import Box from '@mui/material/Box';
import Slider from '@mui/material/Slider';

export default function MaleFemale() {

   const dispatch = useDispatch()
   const [searchParams, setSearchParams] = useSearchParams()
   const gender = useSelector(state => state.gender.gender)
   const subCategory = useSelector(state => state.subcategory.subcategory)
   const category = useSelector(state => state.category.category)
   const products = useSelector(state => state.products.products)
   const maleFemaleQuery = +searchParams.get("gender");
   const categoryQuery = +searchParams.get("category");
   const subcategoryQuery = +searchParams.get("subcategory");
   const { prodValue } = useSelector(state => state.products)
   useEffect(() => {
      dispatch(GetMaleFemale())
      dispatch(GetGenderCategory())
      dispatch(GetSubCategory())
      dispatch(GetProducts())
   }, [])
   // filter
   const [min, setMin] = useState(10);
   const [max, setMax] = useState(10000);
   const [openFilter, setOpenFilter] = useState(false)
   const [value, setValue] = useState([min, max]);
   const handleChange = (newValue) => {
      setValue(newValue);
   };
   useEffect(() => {
      setValue([min, max])
   }, [min, max])
   return (
      <>
         <div className="filter-and-category-box">
            <div className="male-female-category-modal-box">
               {/* maleFemale */}
               <div className='maleFemale'>
                  {gender.map(({ id, logo }) => {
                     const isSelected = (id === maleFemaleQuery);
                     return <div
                        onClick={() => {
                           setSearchParams({ gender: id })
                        }}
                        className={`maleFemaleIcons ${isSelected ? 'selectedBorder' : ''}`}
                        key={id}>
                        <img
                           className='icon'
                           src={logo} />
                     </div>
                  })}
               </div>
               {/* category */}
               <div className='categoryCont'>
                  {
                     category.map((category) => {
                        return category.parentId === maleFemaleQuery && (
                           <div
                              key={category.id}
                              onClick={(() => {
                                 setSearchParams({ gender: maleFemaleQuery, category: category.id })
                              })
                              }
                              style={{ border: category.id === categoryQuery && "2px solid #939393" }}
                              className={`gender-category-item`}
                           >
                              <div className='CategoryImg'>
                                 <img
                                    className='item-category-img'
                                    src={category.categoryImg}
                                    alt={`${category.name}.png`} />
                              </div>
                              <div className='category-img-name'>
                                 {category.name}
                              </div>
                           </div>
                        )
                     })
                  }
               </div>
               {/* modalCategory */}
               <ModalCategory />
            </div>
            {/* Sub Category */}
            <div className='nav-parent-box'>
               <nav className='nav-box'>
                  <ul className='ul-subCategory'>
                     {subCategory.map(({ subname, id, parentId }) => {
                        return parentId === categoryQuery && (
                           <li
                              key={id}
                              className={`li-subCategory`}
                              onClick={(() => {
                                 setSearchParams({ gender: maleFemaleQuery, category: categoryQuery, subcategory: id })
                              })}
                              style={{ borderBottom: id === subcategoryQuery && "4px solid #0008C1" }}
                           > 
                              {subname}
                           </li>
                        )
                     })}
                     <NavModalAdd />
                  </ul>
               </nav>
            </div>
            {/* Products */}
            <div className='products-data-box'>
               <div className='products-data'>
                  {products
                     .filter((val) => {
                        const prodNameMatches = prodValue === "" || val.prodName.toLowerCase().includes(prodValue.toLowerCase());
                        const priceInRange = val.price >= value[0] && val.price <= value[1];
                        return prodNameMatches && priceInRange;
                     })
                     .map(({ id, prodName, price, prodImg, parentId }) => {
                        return subcategoryQuery === parentId && (
                           <div
                              key={id}
                              className='products-item-box'>
                              <div className='products-item'>
                                 <div className='prod-img-box'>
                                    <img
                                       className='product-img'
                                       src={prodImg}
                                       alt={prodName}
                                    />
                                 </div>
                                 <div className='prod-type-and-price'>
                                    <div className="prod-type">
                                       <p>{prodName}</p>
                                    </div>
                                    <div className="prod-price">
                                       <p>{price}<span className="dollar">$</span> </p>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        )
                     })}
               </div>
               <ModalProduct />
            </div>
         </div>
         {/* filter */}
         <div className='filter-box'
            onClick={(() => {
               setOpenFilter(!openFilter)
            })}
            style={{ left: !openFilter ? "0" : "280px" }}>
            <div className='filter-text-and-icon-box'>
               <div className='filter-icon'>
                  <FilterAltOutlinedIcon className='filter-icn' fontSize='large'></FilterAltOutlinedIcon>
               </div>
               <div className='filter-text'>
                  <p>Ф</p>
                  <p>и</p>
                  <p>л</p>
                  <p>ь</p>
                  <p>т</p>
                  <p>p</p>
               </div>
            </div>
            <div className='filter-arrow'>{!openFilter ? <ArrowForwardIosIcon fontSize='small' /> : <ArrowBackIosIcon />}</div>
         </div>
         <div className='range-filter-box'
            style={{ left: !openFilter ? "-300px" : "0" }}>
            <h1 className='filter-price'>Цена</h1>
            <div className='filter-range'>
               <Box sx={{ width: 240 }}>
                  <Slider
                     getAriaLabel={() => 'Temperature range'}
                     value={value}
                     step={50}
                     onChange={handleChange}
                     valueLabelDisplay="auto"
                     min={min}
                     max={max}
                  />
               </Box>
            </div>
            <div className='price-min-max-box'>
               <div className='min-max'>
                  <input
                     type="number"
                     className='filter-input'
                     value={value[0]}
                     onChange={(e) => {
                        setMin(e.target.value)
                        if (e.target.value <= 10) {
                           setMin(10)
                        } else if (e.target.value >= 10000) {
                           setMin(10000)
                        }
                     }}
                  />
               </div>
               <div className='min-max-between'>—</div>
               <div className='min-max'>
                  <input
                     type="number"
                     className='filter-input'
                     value={value[1]}
                     onChange={(e) => {
                        setMax(e.target.value)
                        if (e.target.value >= 10000) {
                           setMax(10000)
                        } else if (e.target.value <= 10) {
                           setMax(10)
                        }
                     }}
                  />
               </div>
            </div>
            <div className="filter-btn-box">
               <button
                  className="btn-filter"
               >Сохранить</button>
            </div>
         </div>
      </>
   )
}