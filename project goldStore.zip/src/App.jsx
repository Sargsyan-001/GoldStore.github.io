import React from 'react';
import Header from "./components/header/Header"
import MaleFemale from './components/maleFemale/MaleFemale';
function App() {
  return (
    <>
      <Header />
      <MaleFemale />
    </>
  );
}
export default App;
